Neon Launcher - тёмный игровой лаунчер для Android.
1. Открой папку в Android Studio (File > Open), дождись Gradle Sync.
2. Build > Build APK(s) - или просто запусти на телефоне.
3. Нажми кнопку "Домой" и выбери Neon Launcher "Всегда".
