package com.neon.launcher

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class App(
        val label: String,
        val pkg: String,
        val icon: Drawable,
        val launch: Intent,
        val isGame: Boolean
    )

    private val cyan = Color.parseColor("#00E5FF")
    private val magenta = Color.parseColor("#FF2BD6")
    private val dim = Color.parseColor("#8F8FB0")

    private var all: List<App> = emptyList()
    private var shown: List<App> = emptyList()

    private lateinit var grid: GridView
    private lateinit var gamesBox: LinearLayout
    private lateinit var gamesRow: LinearLayout
    private lateinit var search: EditText

    private val gridAdapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View =
            tile(shown[position], 48, false)
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)
        loadApps()
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_MAIN) {
            search.setText("")
            grid.setSelection(0)
            hideKeyboard()
        }
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        // Launcher never closes itself
        if (search.text.isNotEmpty()) search.setText("") else grid.setSelection(0)
        hideKeyboard()
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0B0B14"), Color.parseColor("#140A24"))
            )
            setPadding(dp(16), dp(24), dp(16), 0)
            isFocusableInTouchMode = true
        }

        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 54f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setShadowLayer(24f, 0f, 0f, cyan)
        }
        val date = TextClock(this).apply {
            format24Hour = "EEEE, d MMMM"
            format12Hour = "EEEE, d MMMM"
            textSize = 15f
            setTextColor(dim)
        }
        root.addView(clock)
        root.addView(date)

        search = EditText(this).apply {
            hint = "Поиск приложений…"
            setHintTextColor(dim)
            setTextColor(Color.WHITE)
            textSize = 16f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#1A1A2E"))
                setStroke(dp(1), cyan)
            }
            setPadding(dp(18), dp(12), dp(18), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = renderGrid()
            })
            setOnEditorActionListener { _, _, _ ->
                shown.firstOrNull()?.let { launch(it) }
                true
            }
        }
        root.addView(search, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })

        gamesRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        gamesBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(label("▶ ИГРЫ", 12f, magenta).apply {
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.2f
                setShadowLayer(12f, 0f, 0f, magenta)
                setPadding(dp(4), 0, 0, dp(8))
            })
            addView(HorizontalScrollView(this@MainActivity).apply {
                isHorizontalScrollBarEnabled = false
                addView(gamesRow)
            })
        }
        root.addView(gamesBox, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(20) })

        grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(12)
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(0, dp(16), 0, dp(16))
            selector = ColorDrawable(Color.TRANSPARENT)
            adapter = gridAdapter
        }
        root.addView(grid, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        root.requestFocus()
        return root
    }

    private fun tile(app: App, iconDp: Int, glow: Boolean): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
            if (glow) {
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat()
                    setColor(Color.parseColor("#1A1030"))
                    setStroke(dp(1), magenta)
                }
            }
            addView(ImageView(this@MainActivity).apply { setImageDrawable(app.icon) },
                LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)))
            addView(label(app.label, 11f, Color.parseColor("#D0D0E8")).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setPadding(0, dp(4), 0, 0)
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            setOnClickListener { launch(app) }
            setOnLongClickListener { showMenu(this, app); true }
        }

    private fun renderGrid() {
        val q = search.text.toString().trim()
        shown = if (q.isEmpty()) all else all.filter { it.label.contains(q, ignoreCase = true) }
        gridAdapter.notifyDataSetChanged()
        gamesBox.visibility =
            if (q.isEmpty() && gamesRow.childCount > 0) View.VISIBLE else View.GONE
    }

    private fun renderGames() {
        gamesRow.removeAllViews()
        all.filter { it.isGame }.forEach {
            gamesRow.addView(tile(it, 52, true), LinearLayout.LayoutParams(
                dp(80), ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(10) })
        }
    }

    // ---------- Actions ----------

    private fun launch(app: App) {
        try {
            startActivity(app.launch)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось запустить", Toast.LENGTH_SHORT).show()
        }
        hideKeyboard()
    }

    private fun showMenu(anchor: View, app: App) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "О приложении")
            menu.add(0, 2, 1, "Удалить")
            setOnMenuItemClickListener {
                val uri = Uri.parse("package:${app.pkg}")
                when (it.itemId) {
                    1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    2 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                }
                true
            }
        }.show()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    @Suppress("DEPRECATION")
    private fun loadApps() {
        Thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    val ai = ri.activityInfo
                    val info = ai.applicationInfo
                    val game = (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0 ||
                        (Build.VERSION.SDK_INT >= 26 && info.category == ApplicationInfo.CATEGORY_GAME)
                    val intent = Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(ai.packageName, ai.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    App(ri.loadLabel(pm).toString(), ai.packageName, ri.loadIcon(pm), intent, game)
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                all = list
                renderGames()
                renderGrid()
            }
        }.start()
    }
}
